'use strict';

var entryFactory = require('bpmn-js-properties-panel/lib/factory/EntryFactory');

var is = require('bpmn-js/lib/util/ModelUtil').is;
   //var $ = require("jquery");
module.exports = function(group, element) {

  // Only return an entry, if the currently selected
  // element is a bpmn:ServiceTask.

  /*if (is(element, 'bpmn:ServiceTask')) {
    group.entries.push(entryFactory.textField({
      id : 'botList',
      description : 'Fetch Bot List',
      label : 'Bot List',
      modelProperty : 'bot List'
    }));
  } */

  if (is(element, 'bpmn:ServiceTask')) {
    group.entries.push(entryFactory.selectBox({
      id : 'botList',
      description : 'Fetch Bot List',
      label : 'Bot List',
      modelProperty : 'bot List',
      selectOptions:function(element,node){
        //var arrValues = [];
      /* $.ajax({
        url: "www.google.com",
        method :"GET",
        success: function (result) {
          
          arrValues = result; 
        },
        async: false
         });
        return arrValues;
      }*/
      return '{"bot1":"www.bot1.com"}';
      },
      setControlValue:true
    }));
  }
};