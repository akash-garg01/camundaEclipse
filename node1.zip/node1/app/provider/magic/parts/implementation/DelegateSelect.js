'use strict';

var entryFactory = require('bpmn-js-properties-panel/lib/factory/EntryFactory'),
    cmdHelper    = require('bpmn-js-properties-panel/lib/helper/CmdHelper');
   // domQuery = require('min-dom/lib/query'),
    //$ = require('jquery');
var selectValues = require('./delegateSelect.json'); 
//console.log(selectValues);

var DELEGATE_TYPES = [
  'class',
  'expression',
  'delegateExpression'
];

var PROPERTIES = {
  class: 'camunda:class',
  expression: 'camunda:expression',
  delegateExpression: 'camunda:delegateExpression'
};

function isDelegate(type) {
  return DELEGATE_TYPES.indexOf(type) !== -1;
}

function getAttribute(type) {
  return PROPERTIES[type];
}

function getDelegationLabel(type) {
    switch (type) {
    case 'class':
      return 'Java Class';
   /* case 'expression':
      return 'Expression';
    case 'delegateExpression':
      return 'Delegate Expression'; */
    default:
      return '';
    }
}


module.exports = function(element, bpmnFactory, options, translate) {

  var getImplementationType = options.getImplementationType,
      getBusinessObject     = options.getBusinessObject;
  var hideDelegateSelect = options.hideDelegateSelect;

  /*function getDelegationLabel(type) {
    switch (type) {
    case 'class':
      return translate('Java Class');
    case 'expression':
      return translate('Expression');
    case 'delegateExpression':
      return translate('Delegate Expression');
    default:
      return '';
    }
  }*/

  var delegateEntrySelect = entryFactory.selectBox({
    id: 'delegateSelect',
    label: 'Value',
    selectOptions:selectValues,
    modelProperty: 'delegate',
    emptyParameter : false,

    get: function(element, node) {
      var type = getImplementationType(element);
      var bo = getBusinessObject(element);
      var attr = getAttribute(type);
      var label = getDelegationLabel(type);
      return {
        delegate: bo.get(attr),
        delegationLabel: label
      };
    },

    set: function(element, values, node) {
      var bo = getBusinessObject(element);
      var type = getImplementationType(element);
      var attr = getAttribute(type);
      var prop = {};
      prop[attr] = values.delegate || '';
      return cmdHelper.updateBusinessObject(element, bo, prop);
    },

    validate: function(element, values, node) {
      return isDelegate(getImplementationType(element)) && !values.delegate ? { delegate: 'Must provide a value' } : {};
    },
    disabled : function(element,node){        
        if (typeof hideDelegateSelect === 'function') {
        return hideDelegateSelect.apply(delegateEntrySelect, arguments);
            }
    },   

    hidden: function(element, node) {
      return !isDelegate(getImplementationType(element));
    }

  });

  return [ delegateEntrySelect ];

};
