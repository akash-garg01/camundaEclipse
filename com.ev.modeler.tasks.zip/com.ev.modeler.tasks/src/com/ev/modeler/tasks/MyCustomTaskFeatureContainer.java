package com.ev.modeler.tasks;

import org.camunda.bpm.modeler.core.features.activity.task.AbstractCreateTaskFeature;
import org.camunda.bpm.modeler.core.features.api.IDecorateFeature;
import org.camunda.bpm.modeler.core.preferences.ShapeStyle;
import org.camunda.bpm.modeler.core.utils.ExtensionUtil;
import org.camunda.bpm.modeler.core.utils.StyleUtil;
import org.camunda.bpm.modeler.runtime.engine.model.InputOutputType;
import org.camunda.bpm.modeler.runtime.engine.model.ModelFactory;
import org.camunda.bpm.modeler.runtime.engine.model.ModelPackage;
import org.camunda.bpm.modeler.runtime.engine.model.ParameterType;
import org.camunda.bpm.modeler.ui.features.activity.task.AbstractTaskDecorateFeature;
import org.camunda.bpm.modeler.ui.features.activity.task.ServiceTaskFeatureContainer;
import org.eclipse.bpmn2.Bpmn2Package;
import org.eclipse.bpmn2.ServiceTask;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.graphiti.features.ICreateFeature;
import org.eclipse.graphiti.features.IFeatureProvider;
import org.eclipse.graphiti.features.context.ICreateContext;
import org.eclipse.graphiti.mm.algorithms.RoundedRectangle;
import org.eclipse.graphiti.util.IColorConstant;

public class MyCustomTaskFeatureContainer extends ServiceTaskFeatureContainer {

	@Override
	public boolean canApplyTo(Object o) {
		return o instanceof EObject
				&& PluginConstants.isMyCustomTask((EObject) o);
	}

	@Override
	public ICreateFeature getCreateFeature(IFeatureProvider fp) {
		String taskName = PluginConstants.getMyCustomTaskName();
		String createDescription = "A task that talks to an endpoint";

		return new AbstractCreateTaskFeature<ServiceTask>(fp, taskName,
				createDescription) {

			@Override
			protected String getStencilImageId() {

				return com.ev.modeler.helper.Images.IMG_16_SERVICE_TASK;
			}

			@Override
			public ServiceTask createBusinessObject(ICreateContext context) {

				ServiceTask serviceTask = super.createBusinessObject(context);

				serviceTask.setName("bot Integrator");
				serviceTask.eSet(PluginConstants.CLASS_STRUCTURAL_FEATURE,
						PluginConstants.CLASS_VALUE);

				final InputOutputType InputOutput = ModelFactory.eINSTANCE
						.createInputOutputType();

				EStructuralFeature inputFeature = ModelPackage.eINSTANCE
						.getInputOutputType_InputParameters();

			EStructuralFeature outputFeature = ModelPackage.eINSTANCE
						.getInputOutputType_OutputParameters();

				// adding input parameter to service task
				@SuppressWarnings("unchecked")
				EList<ParameterType> inputs = (EList<ParameterType>) InputOutput
						.eGet(inputFeature);

				// adding bot url
				ParameterType inputParameter1 = ModelFactory.eINSTANCE
						.createParameterType();
				inputParameter1.setName("BOT URL");

				ParameterType inputParameter2 = ModelFactory.eINSTANCE
						.createParameterType();
				inputParameter2.setName("RequestMethod");

				ParameterType inputParameter3 = ModelFactory.eINSTANCE
						.createParameterType();
				inputParameter3.setName("RequestContent");

				inputs.add(inputParameter1);
				inputs.add(inputParameter2);
				inputs.add(inputParameter3);

				ExtensionUtil.addExtension(serviceTask,
						PluginConstants.INPUT_OUTPUT_FEATURE, InputOutput);

				
				// adding output parameter to service task
				@SuppressWarnings("unchecked")
				EList<ParameterType> outputs = (EList<ParameterType>) InputOutput
						.eGet(outputFeature);
				

				
				ParameterType outputParameter1 = ModelFactory.eINSTANCE
						.createParameterType();
				outputParameter1.setName("responseCode");
				outputParameter1.setText("#{responseCode}");

				ParameterType outputParameter2 = ModelFactory.eINSTANCE
						.createParameterType();
				outputParameter2.setName("responseBody");
				outputParameter2.setText("#{responseBody}");

				outputs.add(outputParameter1);
				outputs.add(outputParameter2);

				ExtensionUtil.addExtension(serviceTask,
						PluginConstants.INPUT_OUTPUT_FEATURE, InputOutput);

				return serviceTask;
			}

			@Override
			public EClass getBusinessObjectClass() {
				return Bpmn2Package.eINSTANCE.getServiceTask();
			}
		};
	}

	@Override
	public IDecorateFeature getDecorateFeature(IFeatureProvider fp) {
		return new AbstractTaskDecorateFeature(fp) {

			@Override
			protected void decorate(RoundedRectangle decorateContainer) {
				super.decorate(decorateContainer);

				// apply custom color style
				StyleUtil.applyStyle(decorateContainer,
						"ServiceTask.custom.style", new ShapeStyle(
								IColorConstant.WHITE), false);
			}

			@Override
			protected String getIconId() {
				return com.ev.modeler.helper.Images.IMG_16_SERVICE_TASK;
			}
		};
	}

}
