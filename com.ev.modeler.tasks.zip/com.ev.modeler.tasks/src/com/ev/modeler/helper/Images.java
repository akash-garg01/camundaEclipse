package com.ev.modeler.helper;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.graphiti.ui.platform.AbstractImageProvider;

public class Images extends AbstractImageProvider {

	public static final String IMG_16_SERVICE_TASK = Images.class.getName()
			+ "icons/evLogo.16";

	private static Map<String, String> IMAGE_MAP;

	static {
		IMAGE_MAP = new HashMap<String, String>();
		IMAGE_MAP.put(IMG_16_SERVICE_TASK, "icons/evLogo.png");

	}

	// // helpers /////////////////////

	@Override
	protected void addAvailableImages() {
		for (Map.Entry<String, String> entry : IMAGE_MAP.entrySet()) {
			addImageFilePath(entry.getKey(), entry.getValue());
		}
	}

}
