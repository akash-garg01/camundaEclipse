package camundaDelegation;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ServiceTaskDelegation implements JavaDelegate {


	public void execute(DelegateExecution exe) throws Exception {
		System.out.println("Inside Execution of Service Task");
		String botURL = (String) exe.getVariable("BOT URL");
		String requestMethod = (String) exe.getVariable("RequestMethod");
		String content = (String) exe.getVariable("RequestContent");

		System.out.println("variables in service task");
		System.out.println(botURL + "\t" + requestMethod + "\t" + content);
		System.out.println("After execution");
		
		exe.setVariable("responseCode", 200);
		exe.setVariable("responseBody", "Response from delegation");
	}

}
